/** Automatically generated file. DO NOT MODIFY */
package edu.jhu.cs.oose.fall2014.group19.NeverEatAlone;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}