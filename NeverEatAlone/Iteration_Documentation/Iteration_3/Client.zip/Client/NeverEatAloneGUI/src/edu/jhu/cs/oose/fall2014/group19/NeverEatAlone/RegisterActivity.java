package edu.jhu.cs.oose.fall2014.group19.NeverEatAlone;

import edu.jhu.cs.oose.fall2014.group19.NeverEatAlone.R;
import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class RegisterActivity extends ActionBarActivity {

	public final static String USERNAME_MESSAGE = "edu.jhu.cs.oose.fall2014.group19.NeverEatAlone.RegisterActivity.USERNAME";
	public final static String EMAIL_MESSAGE = "edu.jhu.cs.oose.fall2014.group19.NeverEatAlone.RegisterActivity.EMAIL";
	public final static String PASSWORD_MESSAGE = "edu.jhu.cs.oose.fall2014.group19.NeverEatAlone.RegisterActivity.PASSWORD";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/** Called when the user clicks the Register button */
	public void registerRegister(View view) {
		Intent intent = new Intent(this, DisplayMessageActivity.class);

		// Username
		EditText editTextUsername = (EditText) findViewById(R.id.edit_username);
		String messageUsername = editTextUsername.getText().toString();
		intent.putExtra(USERNAME_MESSAGE, messageUsername);

		// Email
		EditText editTextEmail = (EditText) findViewById(R.id.edit_email);
		String messageEmail = editTextEmail.getText().toString();
		intent.putExtra(EMAIL_MESSAGE, messageEmail);

		// Password
		EditText editTextPassword = (EditText) findViewById(R.id.edit_password);
		String messagePassword = editTextPassword.getText().toString();
		intent.putExtra(PASSWORD_MESSAGE, messagePassword);

		startActivity(intent);
	}

	/** Called when the user clicks the Cancel button */
	public void registerCancel(View view) {
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
	}
}
